# Log Analysis project

# Overview
This project in Full Stack web developer nanodegree,
by using Python language and PostgreSQL database to do queries,
answer the following questions and print the results:
1. What are the most popular three articles of all time?
2. Who are the most popular article authors of all time?
3. On which days did more than 1% of requests lead to errors?

# Project Files
1. python_file.py : It contains python script and PostgreSQL queries.
2. newsdata.sql : This is database file.
3. output.txt : It contains the output from python_file.py file.

# How to run
1. Download and install VirtualBox from this site "https://www.virtualbox.org/wiki/Download_Old_Builds_5_1"
2. Download and install vagrant from this site "https://www.vagrantup.com/"
3. Download the VM configuration from "https://github.com/udacity/fullstack-nanodegree-vm"
4. You need to download "newsdata.sql" from this link
"https://d17h27t6h515a5.cloudfront.net/topher/2016/August/57b5f748_newsdata/newsdata.zip"
and move this database to your project folder.
5. For me I used "Windows PowerShell" to run "Vagrant" by these commands:
  * Change directory to "FSND-Virtual-Machine" folder.
  * vagrant up
  * vagrant ssh
  * cd /vagrant
  * psql -d news -f newsdata.sql
  * psql -d news
  * pip3 install psycopg2
  * pip3 install pycodestyle
6. To run project use project folder path and type:
   python3 python_file.py


# My name
Hossam Kabeel
