#!/usr/bin/env python3
import psycopg2

# Connect to the database
db = psycopg2.connect(database="news")
c = db.cursor()
# question1
c.execute("""SELECT title,
       count(title) AS views
FROM articles,
    log
WHERE log.status = '200 OK'
  AND log.path = concat('/article/', articles.slug)
GROUP BY title
ORDER BY views DESC
LIMIT 3;
""")
rows = c.fetchall()
print("1. What are the most popular three articles of all time?\n")
for row in rows:
    print(str(row[0]) + ' === ' + str(row[1]))
# question2
c.execute("""SELECT name,
       count(author) AS views
FROM articles,
     log,
     authors
WHERE log.status = '200 OK'
  AND log.path = concat('/article/', articles.slug)
  AND articles.author = authors.id
GROUP BY name
ORDER BY views DESC;
""")
rows = c.fetchall()
print("\n2. Who are the most popular article authors of all time?\n")
for row in rows:
    print(str(row[0]) + ' === ' + str(row[1]))
# question3
c.execute("""SELECT to_char(DAY, 'Mon DD,YYYY'),
       error_percentage
FROM
  (SELECT date_trunc('day', TIME) AS DAY,
          round(100.0*sum(CASE log.status
                              WHEN '404 NOT FOUND' THEN 1
                              ELSE 0
                          END)/count(log.status), 3) AS error_percentage
   FROM log
   GROUP BY 1
   ORDER BY 1) subq
WHERE error_percentage > 1;
""")
rows = c.fetchall()
print("\n3. On which days did more than 1% of requests lead to errors?\n")
for row in rows:
    print(str(row[0]) + ' === ' + str(row[1]))
db.close()
